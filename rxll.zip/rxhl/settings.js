global.prefa = ['','!','.',',','🐤','🗿']

global.owner = ['6285279522326']
global.botname = 'Rimuru War'
global.baileys1 = require('@whiskeysockets/baileys') 
global.sticker1 = "Rimuru V5"
global.sticker2 = "🌜"